import numpy as np
from scipy.special import logsumexp
from scipy.special import expit

class BaseLoss():

    def __init__(self):
        pass

    def func(self, X, y, w):
        pass

    def grad(self, X, y, w):
        pass


class BinaryLogisticLoss(BaseLoss):
    def __init__(self, l2_coef):
        self.l2_coef = l2_coef

    def func(self, X, y, w):
        exp_to_sum = np.zeros((X.shape[0], 2))
        exp_to_sum[:, 1] = - y * (X @ w[1:] + w[0])
        ans = logsumexp(exp_to_sum, axis=1).mean()
        return ans + self.l2_coef * np.sum(w[1:] ** 2)

    def grad(self, X, y, w):
        X_new = np.c_[np.ones(X.shape[0]), X]
        first = X_new * y[:, np.newaxis]
        second = np.exp(-np.clip(y * (X_new @ w), -10**2, 10**2)) * expit(y * (X_new @ w))
        third = -np.mean(first * second[:, np.newaxis], axis=0)
        third[1:] += self.l2_coef * w[1:] * 2
        return third



