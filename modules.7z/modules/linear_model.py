import numpy as np
import time
class LinearModel:
    def __init__(
        self,
        loss_function,
        batch_size=None,
        step_alpha=1,
        step_beta=0,
        tolerance=1e-5,
        max_iter=10,
        random_seed=911,
        **kwargs
                ):
        self.loss_function = loss_function
        self.batch_size = batch_size
        self.step_alpha = step_alpha
        self.step_beta = step_beta
        self.tolerance = tolerance
        self.max_iter = max_iter
        np.random.seed(random_seed)
        self.random_seed = random_seed
        self.w = None

    def fit(self, X, y, w_0=None, trace=False, X_val=None, y_val=None):
        history = dict()
        history['time'] = []
        history['func'] = []
        history['func_val'] = []
        computed_objects = np.zeros(X.shape[0], dtype=bool)
        objects = np.arange(X.shape[0], dtype=int)
        epoch = 1   #number of current epoch in the while
        stop = False
        w = np.zeros(X.shape[1] + 1) if w_0 is None else w_0
        start_time = time.time()
        batch = X.shape[0] if self.batch_size is None else int(self.batch_size)
        while not stop:
            using_objects = np.random.choice(objects[computed_objects == False],
                min(batch, len(computed_objects[computed_objects == False])), replace=False)
            computed_objects[objects] = 1
            grad = self.loss_function.grad(X[using_objects], y[using_objects], w)
            w -= grad * self.step_alpha / (epoch ** self.step_beta)
            if computed_objects.all:
                c_t = time.time()
                history['func'].append(self.loss_function.func(X, y, w))
                if not X_val is None:
                    history['func_val'].append(self.loss_function.func(X_val, y_val, w))
                epoch += 1
                computed_objects[:] = False
                history['time'].append(c_t - start_time)
                start_time = c_t
                if epoch == self.max_iter + 1 or (epoch >= 3 and (
                        abs(history['func'][epoch-2] - history['func'][epoch-3]) < self.tolerance
                ) ):
                    stop = True
        self.w = w
        if trace:
            return history

    def predict(self, X, treshold=0):
        return np.sign(X@self.w[1:] + self.w[0] - treshold)

    def get_optimal_treshold(self, X, y):
        weights, bias = self.w[1:], self.w[0]
        scores = X.dot(weights) + bias
        y_to_index = {-1: 0, 1: 1}
        # for each score store real targets that correspond score
        score_to_y = dict()
        score_to_y[min(scores) - 1e-5] = [0, 0]
        for one_score, one_y in zip(scores, y):
            score_to_y.setdefault(one_score, [0, 0])
            score_to_y[one_score][y_to_index[one_y]] += 1

        # ith element of cum_sums is amount of y <= alpha
        scores, y_counts = zip(*sorted(score_to_y.items(), key=lambda x: x[0]))
        cum_sums = np.array(y_counts).cumsum(axis=0)

        # count balanced accuracy for each threshold
        recall_for_negative = cum_sums[:, 0] / cum_sums[-1][0]
        recall_for_positive = 1 - cum_sums[:, 1] / cum_sums[-1][1]
        ba_accuracy_values = 0.5 * (recall_for_positive + recall_for_negative)
        best_score = scores[np.argmax(ba_accuracy_values)]
        return best_score

    def get_objective(self, X, y):
        l2 = self.loss_function.l2_coef
        self.loss_function.l2_coef = 0
        ans = self.loss_function.func(X, y, self.w)
        self.loss_function.l2_coef = l2
        return ans

    def get_weights(self):
        return self.w[1:]

    def get_bias(self):
        return self.w[0]





